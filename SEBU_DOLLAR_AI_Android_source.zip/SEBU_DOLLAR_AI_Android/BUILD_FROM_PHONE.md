# Build SEBU DOLLAR AI APK from a phone

This project includes the latest supplied `index_audio_fix.html` as the app's local WebView page and a native Android notification bridge. The signal logic in the HTML is retained.

## Build using GitHub Actions
1. Create a new GitHub repository from the GitHub website and upload the contents of this project (the folder contents, not the ZIP itself).
2. Ensure the repository's default branch is `main`.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build SEBU DOLLAR AI APK**, tap **Run workflow**, and run it on `main`.
5. When the run finishes successfully, open the run and download the artifact named `SEBU-DOLLAR-AI-debug-apk`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on the phone. Allow notification permission when prompted.

This is a debug APK for testing and sideloading, not a Play Store release. Test signal detection and notification delivery on the target phone before sharing. Android battery restrictions, notification permission, connectivity, and process termination can affect delivery.
